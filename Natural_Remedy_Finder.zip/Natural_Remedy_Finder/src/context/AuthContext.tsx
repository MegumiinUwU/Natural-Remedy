import React from 'react'

function AuthContext() {
  return (
    <div>AuthContext</div>
  )
}

export default AuthContext