import React from 'react'

function file() {
  return (
    <div>file</div>
  )
}

export default file