import React from 'react'

function api() {
  return (
    <div>api</div>
  )
}

export default api