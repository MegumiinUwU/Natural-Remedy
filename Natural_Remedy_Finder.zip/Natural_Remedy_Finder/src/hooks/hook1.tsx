import React from 'react'

function hook1() {
  return (
    <div>hook1</div>
  )
}

export default hook1